-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  mer. 23 oct. 2019 à 22:20
-- Version du serveur :  5.7.19
-- Version de PHP :  7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `gestion_commande_lens`
--

-- --------------------------------------------------------

--
-- Structure de la table `migration_versions`
--

DROP TABLE IF EXISTS `migration_versions`;
CREATE TABLE IF NOT EXISTS `migration_versions` (
  `version` varchar(14) COLLATE utf8mb4_unicode_ci NOT NULL,
  `executed_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migration_versions`
--

INSERT INTO `migration_versions` (`version`, `executed_at`) VALUES
('20191023221642', '2019-10-23 22:17:10');

-- --------------------------------------------------------

--
-- Structure de la table `nrh_categorie`
--

DROP TABLE IF EXISTS `nrh_categorie`;
CREATE TABLE IF NOT EXISTS `nrh_categorie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `nrh_client`
--

DROP TABLE IF EXISTS `nrh_client`;
CREATE TABLE IF NOT EXISTS `nrh_client` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `adresse` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_52E430406C6E55B5` (`nom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `nrh_commande`
--

DROP TABLE IF EXISTS `nrh_commande`;
CREATE TABLE IF NOT EXISTS `nrh_commande` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `date_commande` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_78EB217C19EB6921` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `nrh_ligne_commande`
--

DROP TABLE IF EXISTS `nrh_ligne_commande`;
CREATE TABLE IF NOT EXISTS `nrh_ligne_commande` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `commande_id` int(11) NOT NULL,
  `produit_id` int(11) NOT NULL,
  `quantite` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_59FDB0CB82EA2E54` (`commande_id`),
  KEY `IDX_59FDB0CBF347EFB` (`produit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `nrh_produit`
--

DROP TABLE IF EXISTS `nrh_produit`;
CREATE TABLE IF NOT EXISTS `nrh_produit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categorie_id` int(11) NOT NULL,
  `libelle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stock` int(11) NOT NULL,
  `prix_unitaire` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_44EDA8F8BCF5E72D` (`categorie_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `nrh_commande`
--
ALTER TABLE `nrh_commande`
  ADD CONSTRAINT `FK_78EB217C19EB6921` FOREIGN KEY (`client_id`) REFERENCES `nrh_client` (`id`);

--
-- Contraintes pour la table `nrh_ligne_commande`
--
ALTER TABLE `nrh_ligne_commande`
  ADD CONSTRAINT `FK_59FDB0CB82EA2E54` FOREIGN KEY (`commande_id`) REFERENCES `nrh_commande` (`id`),
  ADD CONSTRAINT `FK_59FDB0CBF347EFB` FOREIGN KEY (`produit_id`) REFERENCES `nrh_produit` (`id`);

--
-- Contraintes pour la table `nrh_produit`
--
ALTER TABLE `nrh_produit`
  ADD CONSTRAINT `FK_44EDA8F8BCF5E72D` FOREIGN KEY (`categorie_id`) REFERENCES `nrh_categorie` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
